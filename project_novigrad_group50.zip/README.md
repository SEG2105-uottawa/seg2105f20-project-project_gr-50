# ServiceNovigrad
Build Status

Deliverable 3

Student Names
1) Hamidou Nouhoum Cisse
2) Jiadong Yu
3) Gerald Azichoba

The credentials for the admin account are:
 email/pseudo : admin
 password : admin

The credentials for an employee account are:
email/pseudo : henry@gmail.com
password : 123456

The credentials for a customer account are:
email/pseudo : celia@gmail.com
password : 123456



Employee can add or delete services activated by the admin to their branch account. If admin delete or disable a service, that service will be deleted from all branches.

For the request-answer implementation we are not using dummy data, customer can send request to their desired branches, and these branches can view the requests by clicking "My request" button, and then accept or decline the requests. For Deliverable 4, customers will see notifications about their requests status on their HomePage.
