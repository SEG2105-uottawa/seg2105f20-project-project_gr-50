Deliverable 2

Student Names
1) Hamidou Nouhoum Cisse
2) Jiadong Yu
3) Gerald Azichoba

The credentials for the admin account are:
 email/pseudo : admin
 password : admin

We have incorporated the circlCi building badge for bonus.
